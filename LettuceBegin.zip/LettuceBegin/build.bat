@echo off
echo Building LettuceBegin...
cd LettuceBegin
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o ..\output
echo.
echo Done! Your exe is in the output\ folder.
pause
