using System;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;

namespace LettuceBegin
{
    public partial class MainWindow : Window
    {
        // Lettuce emoji PNG embedded as Base64
        private const string LettuceBase64 = "iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAAA5ZDbSAAAY3ElEQVR4nO2deXAU95XHvzM9R8+MRppRC9BIowMJjSKEQbaxLTtgY7zBBybxGju3HXBI7GylKrBVqdrYqd1ykopTcWXJbu2mTMW7YZ3abIgvbAcfJIBxEguwDBLmMJIACY00QmYOHT33sX+Muunpa7pbI2mE9a2iaqb714f4zHv9fu/3fr8GFrSgBS1oQQta0IIWtKAFLWhBC/r0SDfXN/Bp0+JG4zru93FfqisaTodm6noLgGdQzipDW+0q8xepGsPNS5pMd8m1vdwbP+AfTB7zDyaPeU/F9hbqHhYAF0CuxpK2OJ0I+Udi/QDQvNayvXkt+T2b01Cv5Xx0MNk/cCL+f+cOR34+XeteAKxQpFXvaGxzrK1tLr25erlzjauxpI20GxxibaPhKGKxGMJ0GOOhMSSSSU3XpIPJ/uOvh3dMx6IXAOdR623lm1Z9zrWldc3iB7WeIxqOIhgIaoZ95mD4me636Ce1XHsBsITaN1Zv++xXap8qX0LWF+qcqWQSoyOfwH/Fr/rYC52R3d1vhHeoddkLgHlqva180z3/0PzvYmDrS1dhIu6HP+qd1jWi4SgGLvSrtuYLnZHdR/dMblVzzALgKZFWvePB77f8l5grpkg3bnc/Cop0472hF9ATPDLt66WSSfT3XUIkGlZ1nFrIC4CRjYK3PXv9IbGgqb50Fe5wPwqj3oIRuhd/vLizYNfVCvnonomtFzqju5W0vSYB25xEvXuF6YHqFtP9AECPpQZDw6lu76n4XjqY6ue2bd9YvW3Tds+vxc7jcbbj9upHAQCJdASv9f0Uobj656ecUskk+j7uU+2u394ZvD44nOzK1+6aAkxa9Y5Vm6w7G1Zbtki14QYr926t//Gary79oVg7LlwAOOJ7Caf8B6d1fy6bBy5bE077DyKWirDbx4JjGBwYVHWuwHCi652doevztbtmADurDG13Pu44ZLbqHPnaxsKZEJleclCq68OHe2m8G/sv7dJ8b2bCgjuqH0Vt6SoAwKt9PxUEagPnBzAxMaHqvEpctV7drRanbE6iXilco8GA1rYmhxRcinTjVtfD7PdEOoLDQy9ovjeKdOO+pTtYuH2hDtEo3F1XrfrcTWvJ7+Vrc00AvuXhkueVwq1rqAdpJUX3mwkLNtQ9AaPewm7r8L2Y407ViCLduL9hByjSDQDwR73o8L0k2pYwGEBVUKrOX15lbHNWGdrk2sx7wO4V5gfyJfIZycEFgDuqH4XNWM5+H6F7NXeJGLjMjyWRjuDQpV2yPxZnuVP1dWpXmb8ot3/eA/bcRn5XSbuauhpZuPWlq1g3yuivGl0zHy4A7B/YlTcCJ60k7Ha7qmvVXW/6itz+eQ/YUW28MV+bmroalDnLJPebCUvOcxfIPiu1dInMhAW3T/WbGR0f3Qcf3aPoeEe5Q9X1bE5DvZybnteAnVWGtnzPXrvdLgsXAFqp9TmuGQC6Rt/UdE+fq32CfeYC2efu8dF9io8vsdtgNBhUXVPOTc9rwEaLPFyjwZA3OjUTFlxXsT5nm1brXUGtR6WtKWfbe151bp4wGFDqkP9B8kXVGG6W2jevAedTXUM9iDzW0Eqtz3GngDbrdZgotLseytkm1SXKJ7XBltxj6poFTFVQskEVI771+qNeTda7hpMYYaTVzasNtsxWnYO06h1i++Yt4IbV5Jb2L5X8Rmyf0WDA4spFec/hcbYLrPe0hnSky+YRuGatbp7REtcSVe1LXUSb2HZ1T/Mi0OJG47r2L5X8Rq7eqbLaldc1A4DHcatg28B4t+p7unHxRsG2j64cUn0erkgrCaqC0lQcwNW8AaxkIAFQFjUD2Wcm3+r8Ua/qrBVFukXPM92iAABwuV3Z800D8rwA7KwytK3dYn9VSZWiUtfmtq8SbNNivddV3CnY1luAggBGLrcLVpsVI0M+TfVcRQ9YzSiR3W5XFFgBQBXP6gDAR/eqvr+60jaR8yhLaihVmbMMZrNZU5lPUQdZauAC6gITfloSUA/GZfMIgjQ6ESiIe+aLtJJY9pllkkmQRCQTEttetIDVDAEC2chZqfW6bB7BNi1Q6ktXCs8TUTdwr0bE1GiYGGSp6o6iBbxmi/1VpXCBbOSsVNxUIiNaQ5emUuSHcmUGrJcr0koK/lY6mOyXal+UgFfda/tpeZWxTc0xJXab4rYVFmH6Ui0YM2ER/aFoeY6rVZmzDBbSyn6fvJI+L9W26ADbnER9Y7vlO2qOoSooRf1eRiXGCsG2uMruUTlZI7o9kihcUZ7H2Y5tK36Fde5HBPuqa6vYz/7B5DGpcxQd4BUbLP+ixjUDgNVmzd+II7tJWDmh9hnsEonCARSs6pJbFzYeDwj2K01nFlU3yeYk6vMlMvgyGgyKEhs51+ENDWpRhYh7HimQe6ZId07Rn1T/3FHuwMTEBJavt/6ALNW5PjmfPMwvwisqC17WTn5b7TGkxZK/0QzIVSIMsCYTV6Z9XqYujJFct6vMWcZG1A2rLVtu+ZL9Nw8+XRFsXmvZzrQpKsBqn72A+gqIQshhogT9XwC4Ehma9rn5dWEfjv5Rtj1/7Nhs1Tlu+HzJzvXfLvszadU7igbw4kbjOrXPXgAwm80zcDfycoi4Z0BbX5qrFdT6nAQMnQjkLfqTij+WNJnuWrXJurNoALs8pg1ajlOa3CikyiUAB6LakxwU6RYUDOSzXiDXTfPVsNqypWgAy5WdSElt7VKhVCWS4KATAc310w4ThfsbdgjOp7RkV67Ep2gAK6mO5GuuAizKIrRgrSlKM2HBnbWPC57p76qo5ZLrJhYNYC3P30JKql/LF0W6xQMsDc9fM2HBfUt3CDJil8a7VQ18yGXxigbwbIpOCBMHSlUnMgoFaEtR3up6SABXy1wowmCQfFx9KgFPiGSbxBIXYhIDnEhHVA81rnM/gmUiJUOHvS9oepZLPa6uScAeZztuEKmTkpOJyJ/udJgo8QGGSeVwzYQFG2ofF4XbF+pAv4aqEkJHwGQ2ie4rGsByQ15qxExD4ZfDcuUX6c7w66rEJFbmAwD9E8qgMM9csWIDuZmH+ZTKpCT3FQ1guSEvNWKqLMQCIUZSLtBMyEflUj+aUQXPX2aesJgHUDLzMJ+kiuWLBvC6ys0fccc4tYqbhJACNikxpCc1BAhkAYkNUigplHfZPDnzhLlKpCP444WdBV/7g1HRAD7X4z11h+feaZ+HGyxJAZsQGX4DxCs9GIlVTwLASJ7gagW1HhuXbhf1KAzcmajhYlQ0gHv7Lp1b2/II1FoxoSNyvisJlqQG5e0m8WFEM2ERrZ4EIJltYoIpfvqRUaHhxmIx0e1FA/hY58d/NREWqLHiZCIlACyWZeJLyh1SEhbf5LhV0gLFALlsHjy47CnRYArIuvXfn/thweASOgJhWnytraIBDACDfe9fuMmzWXF7ZgExLmS54IorsWSH1I9DKrgaGO/K+Z6N4B/CxqXbJYsK+kIdePPizmkFVHzNiygaAD48O3CSIt24uVnYR5SSTkeAmPqnRmLJDqPeAgevnMfjbJeE1T9+Mqfdl5t/glZKunt2xPcS3vX+tmBwXTYPPM52AEA8FhdtU1QlO/uOvnjq4S889sAdy76FY+c6FB+n0xFAJiWAo0UO0p3jwm9cfL9kWx/dA5fNg3aRlCNXiXQE+wd2FWTGg5mwoJVaj+sqsvOamVGnaET8R1NUgIOjiQE6EUC1cxkaF7fg/OjZvMeMTQRRZneC0BGwGJUDHqZ7RJMbLlsTm02Ss146EcCDy57KW981QvfiT5eem7bV8sECzA/nOaSSSckpLUUFeODjsc7+8S60UuuxpvmLOD/6dN5jjCYDTHoD4unC3AO3mF3OepUU7hVi+UMxsEDuD2dygpY8vqgA+85PdvnoXrRS63F93V14petfVS3vly8TpUQU6YbDRMFtX6W5+tIf9eI97wvTipIdJgot1J3wOHMj+EQ6gg8v78v54UhF0ECRAQaAjhN/67rD/WibUW/BZ5duwNsnX5Ztn4gnQVhNMKkMFwMy//k3Vz4kWjWpRKf9BzXnlIFs4NTsvEVyMKLD95LA3Y+HxiTPV3SAoxPJkG+yB7Wlq7C25ZG8gKU6+Pkk90yU6r/KiU4E8K73BU2BFEW64XG2o760TdRrjNC9+FBira2xoPx7IIoOMAAM072oLc26yJW1N+DkpeOSbV1T0SuhEx8umw2d9h/E8dF9igMpinSDsrhRZWtCXWmbZN9dDiyjUCAke62iBMz9g66v2yQL2FRmAkkYEU0lZuPWcpRIR9Dhe1G2OI4i3bCbKJSTblTZPKAs4iU/XF0a78ZH/kN5vUEqmcwboxQlYG5w4qmSXvPabrfDbrQhkY6DJIyi5ayEjpDN9EzrPiPZ+6wvXcVeOzvrsAZGidmHUkqkI+gJduCs/5DikaXRkU/ytilKwEDWPVXammAzlkv2iVuqVuR850fRZsLCZrj4kJUW2cmp0takqFBASol0BAPjXegfP6m6kiOVTMoGV4yKDvDSNsc6AIinrob+TZXLBYAtpBVViysRS8dg1JuQSAtTdSVGis1yFYtG6F4M0z3w0b3TymyNjnyiaL2OogJMVZrrmc9Xol42ml1StgJAbjR9XV12n1lvZiHzLZgZ/hOzYqVFdtMRnQjAHxnEMN0Lf9RbsMVZUsmk4qWVigpwZYPtOrHttUuac75bSCsaXPWIpqIArkIWE5PlYoYiGMi2AuStuUqkI/BN9uBK1Asf3YtAdLCgI0ZceQeUT3IrKsC1zaWi01f4wcqNK28CAJAEyUIGAJNefLCfD9mgN6kKgKTkj3rRGzwCH90zo1UZXI0Fx1Rl94oK8PK7XF9nPku50JW1N6CxZClrsQxks94ssEq7kQKhMyGViedAlipeVyql3ZhCK5VMYmTIp+qYogFMVZrrue8LFCu9sdvtWN7QLNjOiOQdwwDnQxZbo1KJppOtKoS8A0OqFkI7czD8TNEAvvle1ze53/nVFUaDAfe1fB4lRhsSqXjOc5exYrE0H5MEYSA7TWWaujZSeeCZlJmwsIWDH3s/UOWaA8OJru636CeLBjDXPQsmeGXiuGv5F2Avy06yMhImAeQyo/QUSi7k1ZWy77AQVSGG/ZSIIt1w2TyosjWBstTk/GDfPSpdKcJXLJwJHZt6gWVRAG7fWL2N654FK9HpTGhwZRf/ik/1d/mQ7dYWwXmzPxQTm+mqsC5Xbb2FetuomLhAXSXCZREZ7bv4S1WuueuNyR3MyndFAfizX6l9ivudv1AonQjApDcjno7BpDeJQhZb+4qRUW+CWW/GjUvUzVcqNFylQBmN0L3o8L2IU30fKL7Ghc7Ibu5KO3MOmG+9DhMlGK7Tp4M537mQGUlVRJr12TU8bqr6huKKSyA7QjQduPxBBjWegxulq0lqiL1beM4B8623wdEuaBOO9QMAa8XZz1nIRsKEEoNdEl4FuQhLy+9TVZ0xQvfi2MiritoyQ38lRgpVNo/qQQZGTJ/aO9GdM9igNKkh9eLoOQV879b6H3OtV+wVN4l0JMdaxSCT5HLJazQv2qzKchPpCA57nxdNb7psHlCkGxWWajjJmmknS0boXvSPdwugMlKa1Dj++uSOc3+J/FJs35wBpirN9as31eS8lk7sFTfJxDAAwEyYEEtlQfMhy81mUAMXyL6MMp5Owm5aDMrizlooWTOtUSNGI3Qv/NFB+KbAyikajipKauR7xeycAb778WW/4L5SXcx6kYmz7jnbRgiZNDerhiilRDoCj+NW3Op6uCDn1DpylEomFa3uruT9wXMCuKGFXM1/f+8NizcK/lMj8exEbW5QxYestThOTEa9ZVqW6o96MTIFVMtMfSALt7/vUl64/GhZSnMCeP1jLc9yv1OkWzjlIxNHYso9A+KQy83lBbNeLWJGkPonujFK9057ji8Dl5lzJSU6mOzvfiO8Q7bRlGYdcEMLuZoZ1GfEf/MncNV6uYP5fMgW6+oZvluhuFUYgxOnAMhP/lIqpXAB4Mieya3RcDqk5LyzDphvvR5nu9AtpoPQpa7WG4lBdljyJwoKKaYbMzCeTTrE00kY9CZkOHC1go6Go4rfqHK5N35g9HziXaXnnlXArsaSNq71ir23FwDS8YsAAJPeiHg6Wy3JhWwzlMBibpzx+2Ws1Tt2BFdi2emm3JEpAIinAYOO0Ax6LDiGwQHlq+QdfXFym+LGmGXAbbdX5Ez+FesW6ZKXeP3eXMgAZtw1c8FOJrP9UJIwAgA7aAFAEjS3klMKdiqZhHdgSNUI0ZmD4WfoYKpfzd8yq4C5I0ai3SIAqeQVQSqSC5kwt86oa+4LdeDKZBeiqShb6wWA9R5KQANCq862y34fC46pfpMZHUz2nzsc+bnav2fWALsaS9q4WSsp62UkBjlDLIKlAMvxi2ko2IfDfb8W1HoB0AQaELpvmqZx2XdZldUyUhNYcTVrgOs+U5bjV5udvKqKTBxIhXI2cSFniEUz9tx9++S/4e2TL7MrC/BrvdSCBnJhe0dHEAqENIEFsq5ZTWDF1awBbljtYFdXqS8VTs3UpUYAAITOgFTmqusyTf2H6k3Sa1hpFZ0I4L8P/YCtuW5w1bP7SCK70Lha0NljEvhk7BMEA0GMh+Qnh+XThc7I7u636Ce1Hj9rgK0lV9coEswq4FkvFzKhMyBj+gxQ4MllQ8E+PPfe91iralzckgOQkVLQ4VQaQ4G+gkBlJDVCpEZzkskSvBIuI5yhTuiytzZTcP/jwHdzkgpNlctzCggAZaCHR0dw3t8z7Rc583XmYPiZ6VguozkBzB9m06XFn00ZY82swKUqKLiXZCswjcSU65UBHU1FcWFgAGeHTxbEUrmig8n+I3smt2p95vI164BFl1ngBVfAFFy9+AKbWiUGFwD+ruEeQdTOWDOQ65JDgTgO97yjKKWoRnQw2X9qf+RpJQMIajRrgMOT2QUi5Rb8ZKUzFxwunQjglQ+eFYBZWXsDKGf2WkxAx635AsCCPnPhnOxcZbWKhTOhoTPRvUOnE695T8X2FuzEHM0a4Audobf4Q4RSyhiXFvz6ezp+JJihaLfbsablNpimLJRbRJD9fhX0oe6/KFrWSU6xcCYUGkp86B9MHvP1xPcXyg3LadYAD3w81gkoeDsn4Sj4c7ejZ5fA8owGAx68aTMLF4Ak6M7+DyXhBoYTXQk6I/ijmDeCRifTo8HhZBcdSPerTTMWQrMG2Hd+sst3frILjWiTa5chKgt63aFgH/Yc+9+cbUaDAV+9/euotF590TJTRADkgr7g8wlW3bvQGdk9k261kJrVtSo73xj+T0DkFXC6KSuaAet95YOc0UkWbm1JHWuhQHZ82UzkXjuejuPAmddyth3dM7H16J7JrfMBLjDLgI/sG3red36yS7CI9lROOqPP/z5cNToxcCDHtTYubsE/3vN91JbUsdu4kIFc0K+eeDmnG6SkBqrYNOurzb787Nmt/IJyFmwBI2c6EcAfpqzXaDDgnpWb8Y3bvg6boQRGvYnNQAFZyHzQPv9ITvLizMHwM/MNLjAHgH3nJ7t2/+zgt3Jepqx3Zt1zAfWXs7+FwUjgnpWb8U/3PYV1y26BSW/MaSMFOpaK482zr7PbmZl6Bb3BWZJuri7cvrF622vP//nX7IZMvKDP337/a6i1Zfvc/Gku2W3CdbWYgYN3zu1nA6tYOBM6tCt0JzOZa75pzhYEv+/Gu1u5478FDa7SQRYuIO6CTXqjqEX7Y36cOH91stfpP9NPz1e4wBwB/tqXN3zzicfu3o5UKGeQv1DSpSfYwQqu+JCz23JBv3PiABtYXe6NH5CaEjJfNOu56B/982M7n3js7u3shlQIulSosLnnqdw2f2wZEGaprm434oS3m426Y+FMSG2BWzFq1gB/7csbvvnd73z+yca6RQ1i+3XJUWRMBQCcyQXHWHI+0HSSxivH97D7u96Y3DEXmadCa8YB5wPLKhMrSKDFVIbwlQ/077p+z7pmpdNC5oNmFPCv/lD+0ZrrmlorLYsUReu61AgyhtrpXTQtv0gK323H03G823eUzVUHhhNdSqeFzAfNWJDVelv5prom44rB6Eu6kch7GUUHpUICF6tKmXjWE+QRoTOwFn3C280uOh4LZ0KHd43fqaV6sVg1Y4BPvx94g/msBrKUi1UkkdIfOR299AE7EMH0d68luMAMd5MO7ov+lvmsGHIqBPDW5FAqXXJUcdv3BzoEcOdzf1dKM5rJIq16xwtvVVy0leoczLYa8qFMpeX2vNdV3W1KB6FLKJvjw4UbGE50/XX3xN9fCxGzmGY8VdnQQq7+2XOlf9ICGYRDcdCli5/L+/yNpML4Xefv2YCqUJWLxaxZyUVPC7LOnC3hkek+6ZKXRAv3uHp/oANvnn0dExMTuNwbP3DqQPgns1EyM9eatcEGMchlxmY02h4XTSsKRDiyw4o6GwubTgTw5pt7926+u+0BsXNcnLyIj4f68beL+3Hl8nho6Ex078XO2P98GsAy+n/oanZiRzKauAAAAABJRU5ErkJggg==";

        public MainWindow()
        {
            InitializeComponent();
            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            // Decode the embedded PNG and set as image source
            byte[] imageBytes = Convert.FromBase64String(LettuceBase64);
            using var ms = new MemoryStream(imageBytes);
            var bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.StreamSource = ms;
            bitmap.EndInit();
            bitmap.Freeze();
            EmojiImage.Source = bitmap;

            // Durations
            var textFadeIn  = TimeSpan.FromSeconds(1.2);
            var textHold    = TimeSpan.FromSeconds(0.4);
            var emojiFadeIn = TimeSpan.FromSeconds(0.9);
            var hold        = TimeSpan.FromSeconds(1.2);
            var fadeOut     = TimeSpan.FromSeconds(0.8);

            // Text fade in
            TitleText.BeginAnimation(OpacityProperty, MakeFade(0, 1, textFadeIn, TimeSpan.Zero));

            // Emoji fade in after text + hold
            var emojiStart = textFadeIn + textHold;
            EmojiImage.BeginAnimation(OpacityProperty, MakeFade(0, 1, emojiFadeIn, emojiStart));

            // Window fade out then exit
            var fadeOutStart = emojiStart + emojiFadeIn + hold;
            var windowOut = MakeFade(1, 0, fadeOut, fadeOutStart);
            windowOut.Completed += (_, _) => Application.Current.Shutdown();
            this.BeginAnimation(OpacityProperty, windowOut);
        }

        private static DoubleAnimation MakeFade(
            double from, double to,
            TimeSpan duration, TimeSpan beginTime)
        {
            return new DoubleAnimation
            {
                From           = from,
                To             = to,
                Duration       = new Duration(duration),
                BeginTime      = beginTime,
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseInOut }
            };
        }
    }
}
