using System.Windows;

namespace LettuceBegin
{
    public partial class App : Application { }
}
